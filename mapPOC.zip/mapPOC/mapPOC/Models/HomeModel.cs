﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace mapPOC.Models
{
    public class HomeModel
    {
        public static int MoveZips(string target, string source, string zips)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                using (SqlCommand cmd = new SqlCommand("sp_updateLevelID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@targetID", target));
                    cmd.Parameters.Add(new SqlParameter("@sourceID", source));
                    cmd.Parameters.Add(new SqlParameter("@zips", zips));
                    rowsEffected = cmd.ExecuteNonQuery();

                }

            }
            return rowsEffected;

        }

        public static int addToMoveZipData(string target, string source, string zips)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_addZipMoveData", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@target", target));
                    cmd.Parameters.Add(new SqlParameter("@source", source));
                    cmd.Parameters.Add(new SqlParameter("@zips", zips));
                    rowsEffected = cmd.ExecuteNonQuery();

                }

            }
            return rowsEffected;

        }


        public static int retrieveMoveZipData(string target, string source, string zips)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                using (SqlCommand cmd = new SqlCommand("sp_getZipMoveData", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@targetID", target));
                    cmd.Parameters.Add(new SqlParameter("@sourceID", source));
                    cmd.Parameters.Add(new SqlParameter("@zips", zips));
                    rowsEffected = cmd.ExecuteNonQuery();
                }

            }
            return rowsEffected;

        }
    }
}