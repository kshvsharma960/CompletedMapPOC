﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mapPOC.Models;
using ShapeChangeUtility;

namespace mapPOC.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public int Add(string src,string tar, string zip)
        {
            int flag = HomeModel.addToMoveZipData(tar, src, zip);
            return flag;            
        }

        public void Move()
        {
            string targetID = "", srcID = "", zipID = "";
            ShapeChange.SQLGetMoveData(out targetID, out  srcID, out  zipID);
            ShapeChange.SQLConnectMove(targetID, srcID, zipID);
            ShapeChange.makeShapeChangeTransactionDelete(srcID, zipID);
            ShapeChange.makeShapeChangeTransactionAdd(targetID, zipID);

        }

    }
}
