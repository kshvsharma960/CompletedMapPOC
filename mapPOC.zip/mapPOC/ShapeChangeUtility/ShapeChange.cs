﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.Data;


namespace ShapeChangeUtility
{
    public class ShapeChange
    {


        public static int SQLConnectMove(string target, string source, string zips)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_updateLevelID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@target", target));
                    cmd.Parameters.Add(new SqlParameter("@source", source));
                    cmd.Parameters.Add(new SqlParameter("@zips", zips));
                    rowsEffected = cmd.ExecuteNonQuery();

                }

            }
            return rowsEffected;

        }


        public static int SQLGetMoveData(out string target, out string source, out string zip)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_getMoveZipData", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@tar", SqlDbType.VarChar, 100));
                    cmd.Parameters.Add(new SqlParameter("@src", SqlDbType.VarChar, 100));
                    cmd.Parameters.Add(new SqlParameter("@zip", SqlDbType.VarChar, 100));
                    cmd.Parameters["@tar"].Direction = ParameterDirection.Output;
                    cmd.Parameters["@src"].Direction = ParameterDirection.Output;
                    cmd.Parameters["@zip"].Direction = ParameterDirection.Output;
                    rowsEffected = cmd.ExecuteNonQuery();
                    target = Convert.ToString(cmd.Parameters["@tar"].Value);
                    source = Convert.ToString(cmd.Parameters["@src"].Value);
                    zip = Convert.ToString(cmd.Parameters["@zip"].Value);
                }

            }
            return rowsEffected;
        }
        /// <summary>
        /// ///////////////////////////////////////////
        /// </summary>
        /// <param name="target"></param>
        /// <param name="source"></param>
        /// <param name="zip"></param>
        /// <returns></returns>

        public static int makeShapeChangeTransactionDelete(string source,  string zip)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("removeShape", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@lvl1IDSrc", source));
                    cmd.Parameters.Add(new SqlParameter("@zipID", zip));

                    rowsEffected = cmd.ExecuteNonQuery();
                }

            }
            return rowsEffected;
        }


        public static int makeShapeChangeTransactionAdd(string target,  string zip)
        {
            int rowsEffected = 0;
            string connstr = ConfigurationSettings.AppSettings["connectionString"];
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("addShape", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@lvl1IDTar", target));
                    cmd.Parameters.Add(new SqlParameter("@zipID", zip));

                    rowsEffected = cmd.ExecuteNonQuery();
                
                }

            }
            return rowsEffected;
        }
        ////////////////////////////////////////////
    }
}
